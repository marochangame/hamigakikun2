(() => {
  'use strict';
  const TOTAL = 90;
  const app = document.getElementById('app');
  const song = document.getElementById('song');
  const startBtn = document.getElementById('startBtn');
  const againVisible = document.getElementById('againVisible');
  const germs = [...document.querySelectorAll('.germ-clean')];
  const sparkles = [...document.querySelectorAll('.sp')];
  let raf = null;
  let startAt = 0;
  let running = false;
  let completed = false;

  function speak(text) {
    try {
      if (!('speechSynthesis' in window)) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'ja-JP';
      u.rate = 0.86;
      u.pitch = 1.55;
      u.volume = 1;
      window.speechSynthesis.speak(u);
    } catch(e) {}
  }

  function reset() {
    if (raf) cancelAnimationFrame(raf);
    raf = null;
    running = false;
    completed = false;
    startAt = 0;
    app.classList.remove('running','done');
    germs.forEach(g => g.classList.remove('gone'));
    sparkles.forEach(s => s.classList.remove('on'));
    try { song.pause(); song.currentTime = 0; } catch(e) {}
    setTimeout(() => speak('リンゴを押して歯磨き始めてね'), 150);
  }

  async function start() {
    if (running) return;
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    reset();
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    running = true;
    app.classList.add('running');
    startAt = performance.now();
    try { song.currentTime = 0; await song.play(); } catch(e) {}
    raf = requestAnimationFrame(tick);
  }

  function tick(now) {
    if (!running || completed) return;
    const elapsed = Math.min(TOTAL, (now - startAt) / 1000);
    const progress = elapsed / TOTAL;
    const activeGerms = Math.min(germs.length, Math.floor(progress * (germs.length + 0.85)));
    germs.forEach((g, i) => { if (i < activeGerms) g.classList.add('gone'); });
    const activeSparkles = Math.min(sparkles.length, Math.floor(progress * (sparkles.length + 0.7)));
    sparkles.forEach((s, i) => { if (i < activeSparkles) s.classList.add('on'); });
    if (elapsed >= TOTAL || song.ended) return finish();
    raf = requestAnimationFrame(tick);
  }

  function finish() {
    completed = true;
    running = false;
    app.classList.remove('running');
    app.classList.add('done');
    germs.forEach(g => g.classList.add('gone'));
    sparkles.forEach(s => s.classList.add('on'));
    try { song.pause(); song.currentTime = 0; } catch(e) {}
    setTimeout(() => speak('もう一度歯磨きするならリンゴを押してね'), 250);
  }

  startBtn.addEventListener('click', start);
  startBtn.addEventListener('touchend', (e)=>{ e.preventDefault(); start(); }, {passive:false});
  againVisible.addEventListener('click', reset);
  againVisible.addEventListener('touchend', (e)=>{ e.preventDefault(); reset(); }, {passive:false});
  song.addEventListener('ended', finish);
  window.addEventListener('pagehide', () => { try { song.pause(); } catch(e){} });
  reset();
})();
